
import React from 'react';
import { useAuth } from '../context/AuthContext';

interface CardProps {
  title: string;
  children: React.ReactNode;
  isActive?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export const Card: React.FC<CardProps> = ({ title, children, isActive, onClick, disabled }) => {
  return (
    <div 
      onClick={!disabled ? onClick : undefined}
      className={`
        p-4 border rounded-lg transition-colors
        ${disabled ? 'opacity-50 cursor-not-allowed bg-gray-50' : 'cursor-pointer'}
        ${isActive ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}
      `}
      id={`card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <h3 className="font-semibold text-sm mb-2 text-gray-700">{title}</h3>
      <div className="text-sm text-gray-600">
        {children}
      </div>
    </div>
  );
};

export const SectionHeader: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="mb-6 border-b pb-2" id={`section-header-${title.toLowerCase().replace(/\s+/g, '-')}`}>
    <h2 className="text-xl font-bold text-gray-800">{title}</h2>
    {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
  </div>
);

export const ContextBar: React.FC = () => {
  const { selectedUser, selectedTenant, selectedBU, selectedApp, currentRole, isGlobalRole } = useAuth();

  return (
    <div className="bg-gray-900 text-white p-3 text-xs font-mono flex flex-wrap gap-4 sticky top-0 z-10 shadow-md" id="context-bar">
      <div className="flex gap-2">
        <span className="text-gray-400">USER:</span>
        <span className={selectedUser ? "text-green-400" : "text-red-400"}>
          {selectedUser?.name || 'NONE'}
        </span>
      </div>
      <div className="flex gap-2">
        <span className="text-gray-400">TENANT:</span>
        <span className={selectedTenant ? "text-green-400" : "text-red-400"}>
          {selectedTenant?.name || 'NONE'}
        </span>
      </div>
      <div className="flex gap-2">
        <span className="text-gray-400">BU:</span>
        <span className={(selectedBU || isGlobalRole) ? "text-green-400" : "text-red-400"}>
          {isGlobalRole ? 'ALL' : (selectedBU?.name || 'NONE')}
        </span>
      </div>
      <div className="flex gap-2">
        <span className="text-gray-400">ROLE:</span>
        <span className={currentRole ? "text-blue-400" : "text-red-400"}>
          {currentRole?.name || 'NONE'}
          {currentRole && (
            <span className="ml-1 text-[10px] bg-blue-900 px-1 rounded border border-blue-700">
              {currentRole.scope}
            </span>
          )}
        </span>
      </div>
      <div className="flex gap-2">
        <span className="text-gray-400">APP:</span>
        <span className={selectedApp ? "text-green-400" : "text-red-400"}>
          {selectedApp?.name || 'NONE'}
        </span>
      </div>
    </div>
  );
};
