
export interface User {
  id: string;
  name: string;
}

export interface Tenant {
  id: string;
  name: string;
}

export interface BusinessUnit {
  id: string;
  tenantId: string;
  name: string;
}

export interface Application {
  id: string;
  name: string;
}

export interface Role {
  id: string;
  name: string;
  scope: 'GLOBAL' | 'BU_SCOPED';
  allowedApps: string[]; // App IDs
  permissions: Record<string, string[]>; // appId -> list of control names
}

export interface Assignment {
  userId: string;
  tenantId: string;
  buId: string | 'GLOBAL';
  roleId: string;
}

export const USERS: User[] = [
  { id: 'u1', name: 'Alice Smith (Global Admin)' },
  { id: 'u2', name: 'Bob Jones (Regional Manager)' },
  { id: 'u3', name: 'Charlie Brown (Business User)' },
];

export const TENANTS: Tenant[] = [
  { id: 't1', name: 'Acme Corp' },
  { id: 't2', name: 'Globex Inc' },
];

export const BUS: BusinessUnit[] = [
  { id: 'bu1', tenantId: 't1', name: 'Acme North America' },
  { id: 'bu2', tenantId: 't1', name: 'Acme EMEA' },
  { id: 'bu3', tenantId: 't2', name: 'Globex Logistics' },
  { id: 'bu4', tenantId: 't2', name: 'Globex R&D' },
];

export const APPLICATIONS: Application[] = [
  { id: 'app1', name: 'Finance Portal' },
  { id: 'app2', name: 'Inventory Manager' },
  { id: 'app3', name: 'HR System' },
  { id: 'app4', name: 'CRM' },
];

export const ALL_CONTROLS = ['View', 'Edit', 'Delete', 'Approve'];

export const ROLES: Role[] = [
  {
    id: 'r_admin',
    name: 'Administrator',
    scope: 'GLOBAL',
    allowedApps: ['app1', 'app2', 'app3', 'app4'],
    permissions: {
      app1: ['View', 'Edit', 'Delete', 'Approve'],
      app2: ['View', 'Edit', 'Delete', 'Approve'],
      app3: ['View', 'Edit', 'Delete', 'Approve'],
      app4: ['View', 'Edit', 'Delete', 'Approve'],
    },
  },
  {
    id: 'r_manager',
    name: 'Manager',
    scope: 'BU_SCOPED',
    allowedApps: ['app1', 'app2', 'app4'],
    permissions: {
      app1: ['View', 'Edit', 'Approve'],
      app2: ['View', 'Edit', 'Approve'],
      app4: ['View', 'Edit'],
    },
  },
  {
    id: 'r_user',
    name: 'Business User',
    scope: 'BU_SCOPED',
    allowedApps: ['app2', 'app4'],
    permissions: {
      app2: ['View'],
      app4: ['View', 'Edit'],
    },
  },
];

export const ASSIGNMENTS: Assignment[] = [
  // Alice is Admin at Tenant level for Acme
  { userId: 'u1', tenantId: 't1', buId: 'GLOBAL', roleId: 'r_admin' },
  // Bob is Manager in Acme EMEA and Globex Logistics
  { userId: 'u2', tenantId: 't1', buId: 'bu2', roleId: 'r_manager' },
  { userId: 'u2', tenantId: 't2', buId: 'bu3', roleId: 'r_manager' },
  // Charlie is User in Globex R&D
  { userId: 'u3', tenantId: 't2', buId: 'bu4', roleId: 'r_user' },
  // Charlie is also Manager in Acme North America
  { userId: 'u3', tenantId: 't1', buId: 'bu1', roleId: 'r_manager' },
];
