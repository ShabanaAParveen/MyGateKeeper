
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { USERS, ALL_CONTROLS } from '../services/mockData';
import { Card, SectionHeader } from '../components/UI';

export const UserSelection: React.FC = () => {
  const { selectedUser, setSelectedUser } = useAuth();

  return (
    <div id="user-selection-feature">
      <SectionHeader title="Step 1: Select User" subtitle="Identify the person requesting access" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {USERS.map(user => (
          <Card 
            key={user.id}
            title={user.name}
            isActive={selectedUser?.id === user.id}
            onClick={() => setSelectedUser(user)}
          >
            ID: {user.id}
          </Card>
        ))}
      </div>
    </div>
  );
};

export const TenantSelection: React.FC = () => {
  const { selectedUser, selectedTenant, setSelectedTenant, availableTenants } = useAuth();

  if (!selectedUser) return null;

  return (
    <div id="tenant-selection-feature" className="mt-8">
      <SectionHeader title="Step 2: Select Tenant" subtitle={`Available organizations for ${selectedUser.name}`} />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {availableTenants.map(tenant => (
          <Card 
            key={tenant.id}
            title={tenant.name}
            isActive={selectedTenant?.id === tenant.id}
            onClick={() => setSelectedTenant(tenant)}
          >
            Boundary ID: {tenant.id}
          </Card>
        ))}
      </div>
    </div>
  );
};

export const BUSelection: React.FC = () => {
  const { selectedTenant, selectedBU, setSelectedBU, availableBUs, isGlobalRole, currentRole } = useAuth();

  if (!selectedTenant) return null;

  if (isGlobalRole) {
    return (
      <div id="bu-selection-feature" className="mt-8">
        <SectionHeader title="Step 3: Business Unit Scope" subtitle={`Role: ${currentRole?.name} has Global Scope`} />
        <div className="p-6 border-2 border-dashed border-blue-200 bg-blue-50 rounded-lg text-center">
          <p className="text-blue-700 font-semibold text-lg">ALL BUSINESS UNITS</p>
          <p className="text-blue-500 text-sm mt-1">Global scope role detected. BU selection is not required.</p>
        </div>
      </div>
    );
  }

  return (
    <div id="bu-selection-feature" className="mt-8">
      <SectionHeader title="Step 3: Select Business Unit" subtitle={`Scope of operations within ${selectedTenant.name}`} />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {availableBUs.map(bu => (
          <Card 
            key={bu.id}
            title={bu.name}
            isActive={selectedBU?.id === bu.id}
            onClick={() => setSelectedBU(bu)}
          >
            Scope ID: {bu.id}
          </Card>
        ))}
      </div>
    </div>
  );
};

export const AppSelection: React.FC = () => {
  const { selectedBU, selectedApp, setSelectedApp, availableApps, currentRole, isGlobalRole } = useAuth();

  if (!selectedBU && !isGlobalRole) return null;

  return (
    <div id="app-selection-feature" className="mt-8">
      <SectionHeader 
        title="Step 4: Display Applications" 
        subtitle={`Applications derived from Role: ${currentRole?.name}`} 
      />
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {availableApps.map(app => (
          <Card 
            key={app.id}
            title={app.name}
            isActive={selectedApp?.id === app.id}
            onClick={() => setSelectedApp(app)}
          >
            App ID: {app.id}
          </Card>
        ))}
      </div>
      {availableApps.length === 0 && (
        <div className="p-4 bg-yellow-50 border border-yellow-200 text-yellow-700 rounded-lg">
          No applications assigned to this role in this Business Unit.
        </div>
      )}
    </div>
  );
};

export const ControlsView: React.FC = () => {
  const { selectedApp, currentRole } = useAuth();

  if (!selectedApp || !currentRole) return null;

  const allowedControls = currentRole.permissions[selectedApp.id] || [];

  return (
    <div id="controls-feature" className="mt-8 mb-12">
      <SectionHeader 
        title="Step 5: Display Controls" 
        subtitle={`Permissions for ${selectedApp.name} based on ${currentRole.name} role`} 
      />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {ALL_CONTROLS.map((control: string) => {
          const isAllowed = allowedControls.includes(control);
          return (
            <div 
              key={control}
              className={`
                p-6 border rounded-lg flex flex-col items-center justify-center text-center
                ${isAllowed ? 'border-green-500 bg-green-50' : 'border-red-200 bg-red-50 opacity-60'}
              `}
              id={`control-${control.toLowerCase()}`}
            >
              <div className={`text-lg font-bold ${isAllowed ? 'text-green-700' : 'text-red-700'}`}>
                {control}
              </div>
              <div className="text-xs mt-1 uppercase tracking-wider font-semibold">
                {isAllowed ? 'ENABLED' : 'DISABLED'}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
