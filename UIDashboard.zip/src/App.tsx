/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { ContextBar } from './components/UI';
import { 
  UserSelection, 
  TenantSelection, 
  BUSelection, 
  AppSelection, 
  ControlsView 
} from './features/AuthFeatures';

export default function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50 flex flex-col font-sans" id="app-root">
        <header className="bg-white border-b p-4 flex justify-between items-center">
          <div>
            <h1 className="text-lg font-bold text-gray-900 tracking-tight">Enterprise Auth Simulator</h1>
            <p className="text-xs text-gray-500 font-mono">Multi-Tenant / Multi-BU Authorization Model</p>
          </div>
          <div className="text-xs text-gray-400 italic">
            Simulation Mode: Active
          </div>
        </header>

        <ContextBar />

        <main className="flex-1 max-w-6xl mx-auto w-full p-6 space-y-8">
          <UserSelection />
          <TenantSelection />
          <BUSelection />
          <AppSelection />
          <ControlsView />
        </main>

        <footer className="bg-white border-t p-6 mt-auto">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-4">
            <div className="text-xs text-gray-500">
              <p className="font-bold mb-1">Access Model Logic:</p>
              <p>1. User + Tenant + BU = Role</p>
              <p>2. Role = [Applications]</p>
              <p>3. Role + Application = [Controls]</p>
            </div>
            <div className="text-xs text-gray-400 max-w-md">
              This UI demonstrates contextual authorization. Unlike simple RBAC, capabilities are scoped by the organizational boundary (Tenant) and operational scope (Business Unit).
            </div>
          </div>
        </footer>
      </div>
    </AuthProvider>
  );
}
