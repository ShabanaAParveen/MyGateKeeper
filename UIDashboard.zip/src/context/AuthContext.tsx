
import React, { createContext, useContext, useState, ReactNode, useMemo } from 'react';
import { 
  User, Tenant, BusinessUnit, Application, Role, 
  USERS, TENANTS, BUS, APPLICATIONS, ROLES, ASSIGNMENTS 
} from '../services/mockData';

interface AuthContextType {
  selectedUser: User | null;
  selectedTenant: Tenant | null;
  selectedBU: BusinessUnit | null;
  selectedApp: Application | null;
  
  setSelectedUser: (user: User | null) => void;
  setSelectedTenant: (tenant: Tenant | null) => void;
  setSelectedBU: (bu: BusinessUnit | null) => void;
  setSelectedApp: (app: Application | null) => void;
  
  availableTenants: Tenant[];
  availableBUs: BusinessUnit[];
  currentRole: Role | null;
  isGlobalRole: boolean;
  availableApps: Application[];
  
  reset: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null);
  const [selectedBU, setSelectedBU] = useState<BusinessUnit | null>(null);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  const reset = () => {
    setSelectedUser(null);
    setSelectedTenant(null);
    setSelectedBU(null);
    setSelectedApp(null);
  };

  const availableTenants = useMemo(() => {
    if (!selectedUser) return [];
    const tenantIds = ASSIGNMENTS
      .filter(a => a.userId === selectedUser.id)
      .map(a => a.tenantId);
    return TENANTS.filter(t => tenantIds.includes(t.id));
  }, [selectedUser]);

  const availableBUs = useMemo(() => {
    if (!selectedUser || !selectedTenant) return [];
    const buIds = ASSIGNMENTS
      .filter(a => a.userId === selectedUser.id && a.tenantId === selectedTenant.id)
      .map(a => a.buId);
    return BUS.filter(bu => buIds.includes(bu.id));
  }, [selectedUser, selectedTenant]);

  const currentRole = useMemo(() => {
    if (!selectedUser || !selectedTenant) return null;
    
    // Check for Global assignment first
    const globalAssignment = ASSIGNMENTS.find(
      a => a.userId === selectedUser.id && 
           a.tenantId === selectedTenant.id && 
           a.buId === 'GLOBAL'
    );
    
    if (globalAssignment) {
      return ROLES.find(r => r.id === globalAssignment.roleId) || null;
    }

    // Otherwise check for BU-specific assignment
    if (!selectedBU) return null;
    const buAssignment = ASSIGNMENTS.find(
      a => a.userId === selectedUser.id && 
           a.tenantId === selectedTenant.id && 
           a.buId === selectedBU.id
    );
    return ROLES.find(r => r.id === buAssignment?.roleId) || null;
  }, [selectedUser, selectedTenant, selectedBU]);

  const isGlobalRole = currentRole?.scope === 'GLOBAL';

  const availableApps = useMemo(() => {
    if (!currentRole) return [];
    return APPLICATIONS.filter(app => currentRole.allowedApps.includes(app.id));
  }, [currentRole]);

  const value = {
    selectedUser,
    selectedTenant,
    selectedBU,
    selectedApp,
    setSelectedUser: (u: User | null) => {
      setSelectedUser(u);
      setSelectedTenant(null);
      setSelectedBU(null);
      setSelectedApp(null);
    },
    setSelectedTenant: (t: Tenant | null) => {
      setSelectedTenant(t);
      setSelectedBU(null);
      setSelectedApp(null);
    },
    setSelectedBU: (bu: BusinessUnit | null) => {
      setSelectedBU(bu);
      setSelectedApp(null);
    },
    setSelectedApp,
    availableTenants,
    availableBUs,
    currentRole,
    isGlobalRole,
    availableApps,
    reset
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
